
public class GorillaTest {

	public static void main(String[] args) {

		Gorilla gorilla = new Gorilla(50); // instantiate

		gorilla.displayEnergyLevel();
		gorilla.throwThings();
		gorilla.throwThings();
		gorilla.throwThings();
		gorilla.displayEnergyLevel();
		gorilla.eatBananas();
		gorilla.eatBananas();
		gorilla.displayEnergyLevel();
		gorilla.climb();
		gorilla.displayEnergyLevel();

	}

}
