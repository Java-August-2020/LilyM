package com.Lily.eventsBeltReviewer.models;

public class State {
	public static final String[] States = {
		"CA", "OR", "WA", "TX", "NV", "IL"
	};
}